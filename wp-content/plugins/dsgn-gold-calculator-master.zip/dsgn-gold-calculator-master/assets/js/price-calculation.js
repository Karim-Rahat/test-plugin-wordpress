document.addEventListener("input", function (e) {
  if (!e.target.classList.contains("dsgn-gold-number-input")) return;

  const input = e.target;

  // block negative
  if (input.value < 0) input.value = 0;

  const row = input.closest("tr");
  const weight = parseFloat(input.value) || 0;

  const priceText = row.children[2].innerText;
  const pricePerGram = parseFloat(priceText.replace("£", "")) || 0;

  const value = format2Decimals(weight * pricePerGram);

  // update row value (2 decimal, NO rounding)
  row.querySelector(".dsgn-gold-value").textContent = `£${value}`;

  updateTotals();
});

function updateTotals() {
  const visibleTable = document.querySelector(
    ".dsgn-gold-carat-table-price table:not([style*='display: none'])"
  );
  if (!visibleTable) return;

  let total = 0;

  visibleTable.querySelectorAll(".dsgn-gold-value").forEach(cell => {
    total += parseFloat(cell.textContent.replace("£", "")) || 0;
  });

  total = format2Decimals(total);

  const metal = visibleTable.dataset.metal;

  if (metal === "gold") {
    document.querySelector(".dsgn-gold-g-final-price").textContent = `£${total}`;
  } else if (metal === "platinum") {
    document.querySelector(".dsgn-gold-p-final-price").textContent = `£${total}`;
  } else if (metal === "silver") {
    document.querySelector(".dsgn-gold-s-final-price").textContent = `£${total}`;
  }
  else if (metal === "palladium") {
    document.querySelector(".dsgn-gold-pa-final-price").textContent = `£${total}`;
  }

  const gold = parseFloat(document.querySelector(".dsgn-gold-g-final-price").textContent.replace("£", "")) || 0;
  const plat = parseFloat(document.querySelector(".dsgn-gold-p-final-price").textContent.replace("£", "")) || 0;
  const silver = parseFloat(document.querySelector(".dsgn-gold-s-final-price").textContent.replace("£", "")) || 0;
  const palladium = parseFloat(document.querySelector(".dsgn-gold-pa-final-price").textContent.replace("£", "")) || 0;

  const estimated = format2Decimals(gold + plat + silver + palladium);

  document.querySelector(".dsgn-gold-estimated-price").textContent = `£${estimated}`;
}

// truncate helper
function format2Decimals(num) {
  return Math.floor(num * 100) / 100;
}