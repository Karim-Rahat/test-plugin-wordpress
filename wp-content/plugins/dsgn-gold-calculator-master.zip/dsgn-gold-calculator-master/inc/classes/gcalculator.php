<?php

/**
 * Main Class File For The Whole Plugin
 * @package GOLD_CALCULATOR
 * @since 1.0
 */

namespace GOLD_CALCULATOR\Inc\Classes;

/**
 * Exit if accessed directly
 */
if (!defined("ABSPATH")) {
    exit;
}

use GOLD_CALCULATOR\Inc\Traits\Singleton;

class GCALCULATOR
{
    use Singleton;
    public function __construct()
    {
        Assets::get_instance();
        Shortcodes::get_instance();
        Actions::get_instance();

        $this->setup_hooks();
    }

    public function setup_hooks()
    {

    }

}
