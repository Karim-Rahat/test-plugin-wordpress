<section class="dsgn-gold-tab-bg dsgn-gold">

    <div class="dsgn-gold-title-div">
        <h1 class="dsgn-gold-tab-title">Instant Gold Offer</h1>
        <p class="dsgn-gold-tab-para">Please enter your item information below to receive an instant quote.</p>
    </div>
    <div class="dsgn-gold-tab-container">
        <div class="dsgn-gold-tab-items">
            <div class="dsgn-gold-tab-contain dsgn-gold-active">
                <li class="dsgn-gold-tab dsgn-gold-active" data-tab="gold">Gold</li>
            </div>
            <div class="dsgn-gold-tab-contain">
                <li class="dsgn-gold-tab" data-tab="silver">Silver</li>
            </div>
            <div class="dsgn-gold-tab-contain">
                <li class="dsgn-gold-tab" data-tab="platinum">Platinum</li>
            </div>
            <div class="dsgn-gold-tab-contain">
                <li class="dsgn-gold-tab" data-tab="palladium">Palladium</li>
            </div>
        </div>
        <div class="dsgn-gold-tab-body">
            <div id="loaderOverlay" class="page-loader"></div>

            <div class="dsgn-gold-tab-card-container" id="tabCardContainer">
                <!-- GOLD CARD -->
                <!-- <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">9ct Gold</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£43.85</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">28/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div>
                    <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">14ct Gold</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£68.40</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">28/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div>
                    <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">18ct Gold</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£87.23</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">28/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div>
                    <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">21ct Gold</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£102.26</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">28/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div>
                    <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">22ct Gold</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£107.11</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">28/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div>
                    <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">24ct Gold</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£116.92</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">28/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div> -->
                <!-- PLATINUM CARD-->
                <!-- <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">950 PLT</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£49.02</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">29/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div> -->
                <!-- SLIVER CARD -->
                <!-- <div class="dsgn-gold-tab-card">
                        <h6 class="dsgn-gold-ct">950 SLV</h6>
                        <div class="dsgn-gold-tab-card-body">
                            <p class="dsgn-gold-price">£1.96</p>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/calendar-02.svg" alt="" />
                                <p class="dsgn-gold-date">29/01/2026</p>
                            </div>
                            <div class="dsgn-gold-i-date">
                                <img src="./assets/time-01.svg" alt="" />
                                <p class="dsgn-gold-date">05:15</p>
                            </div>
                        </div>
                    </div> -->
            </div>

            <div class="dsgn-gold-carat-table-price">
                <div class="dsgn-gold-table-link">
                    <!-- table for pc -->
                    <div class="dsgn-gold-table-pc-div">
                        <!-- gold table -->
                        <table data-metal="gold" class="dsgn-gold-table">
                            <thead>
                                <tr>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Metal Carat</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-weight dsgn-gold-font16">Weight (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-price-gram dsgn-gold-font16">Price (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- <tr>
                                        <td>9ct Gold</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="9ct Gold" />
                                        </td>
                                        <td>
                                            £43.85
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>14ct Gold</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="14ct Gold" />
                                        </td>
                                        <td>
                                            £68.40
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>18ct Gold</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="18ct Gold" />
                                        </td>
                                        <td>
                                            £87.23
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>21ct Gold</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="21ct Gold" />
                                        </td>
                                        <td>
                                            £102.26
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>22ct Gold</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="22ct Gold" />
                                        </td>
                                        <td>
                                            £107.11
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>24ct Gold</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="24ct Gold" />
                                        </td>
                                        <td>
                                            £116.92
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr> -->
                            </tbody>
                        </table>
                        <!-- platinum table -->
                        <table data-metal="platinum" class="dsgn-gold-table">
                            <thead>
                                <tr>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Metal Carat</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-weight dsgn-gold-font16">Weight (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-price-gram dsgn-gold-font16">Price (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- <tr>
                                        <td>950 PLT</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="950 PLT" />
                                        </td>
                                        <td>
                                            £49.40
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>999 PLT</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="999 PLT" />
                                        </td>
                                        <td>
                                            £51.97
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr> -->
                            </tbody>
                        </table>
                        <!-- silver table -->
                        <table data-metal="silver" class="dsgn-gold-table">
                            <thead>
                                <tr>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Metal Carat</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-weight dsgn-gold-font16">Weight (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-price-gram dsgn-gold-font16">Price (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- <tr>
                                        <td>925 SLV</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="925 SLV" />
                                        </td>
                                        <td>
                                            £1.95
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>999 SLV</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="999 SLV" />
                                        </td>
                                        <td>
                                            £2.24
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr> -->
                            </tbody>
                        </table>
                        <!-- palladium table -->
                        <table data-metal="palladium" class="dsgn-gold-table">
                            <thead>
                                <tr>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Metal Carat</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-weight dsgn-gold-font16">Weight (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-price-gram dsgn-gold-font16">Price (g)</th>
                                    <th class="dsgn-gold-t-head dsgn-gold-font16">Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- <tr>
                                        <td>925 SLV</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="925 SLV" />
                                        </td>
                                        <td>
                                            £1.95
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr>
                                    <tr>
                                        <td>999 SLV</td>
                                        <td class="dsgn-gold-number-div">
                                            <input class="dsgn-gold-number-input" type="number" value="0" min="0" step="0.1" data-carat="999 SLV" />
                                        </td>
                                        <td>
                                            £2.24
                                            <img src="./assets/alert-circle.svg" alt="alert" />
                                        </td>
                                        <td class="dsgn-gold-value dsgn-gold-font16">£0.00</td>
                                    </tr> -->
                            </tbody>
                        </table>
                    </div>
                    <!-- table for mobile only -->
                    <div class="dsgn-gold-table-mble-div">
                        <!-- gold table -->
                        <div class="dsgn-gold-table-mble" data-metal="gold">
                            <h5 class="dsgn-gold-gold dsgn-gold-font16">9ct Gold</h5>
                            <div class="dsgn-gold-head-table-element">
                                <div class="dsgn-gold-head-table">
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title1 ab">Weight (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title2">price (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title3">Value</p>
                                </div>
                                <div class="dsgn-gold-t-field">
                                    <input class="dsgn-gold-number-input dsgn-gold-table-title1" type="number" value="0"
                                        min="0" step="0.1" data-carat="${item.carat}" />
                                    <p class="dsgn-gold-p-i dsgn-gold-table-title2">£34.36</p>
                                    <p class="dsgn-gold-value dsgn-gold-table-title3">£0.00</p>
                                </div>
                            </div>
                        </div>
                        <!-- platinum table -->
                        <div class="dsgn-gold-table-mble" data-metal="platinum">
                            <h5 class="dsgn-gold-gold dsgn-gold-font16">9ct Gold</h5>
                            <div class="dsgn-gold-head-table-element">
                                <div class="dsgn-gold-head-table">
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title1 ab">Weight (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title2">price (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title3">Value</p>
                                </div>
                                <div class="dsgn-gold-t-field">
                                    <input class="dsgn-gold-number-input dsgn-gold-table-title1" type="number" value="0"
                                        min="0" step="0.1" data-carat="${item.carat}" />
                                    <p class="dsgn-gold-p-i dsgn-gold-table-title2">£34.36</p>
                                    <p class="dsgn-gold-value dsgn-gold-table-title3">£0.00</p>
                                </div>
                            </div>
                        </div>
                        <!-- silver table -->
                        <div class="dsgn-gold-table-mble" data-metal="silver">
                            <h5 class="dsgn-gold-gold dsgn-gold-font16">9ct Gold</h5>
                            <div class="dsgn-gold-head-table-element">
                                <div class="dsgn-gold-head-table">
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title1 ab">Weight (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title2">price (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title3">Value</p>
                                </div>
                                <div class="dsgn-gold-t-field">
                                    <input class="dsgn-gold-number-input dsgn-gold-table-title1" type="number" value="0"
                                        min="0" step="0.1" data-carat="${item.carat}" />
                                    <p class="dsgn-gold-p-i dsgn-gold-table-title2">£34.36</p>
                                    <p class="dsgn-gold-value dsgn-gold-table-title3">£0.00</p>
                                </div>
                            </div>
                        </div>
                        <!-- palladium table -->
                        <div class="dsgn-gold-table-mble" data-metal="palladium">
                            <h5 class="dsgn-gold-gold dsgn-gold-font16">9ct Gold</h5>
                            <div class="dsgn-gold-head-table-element">
                                <div class="dsgn-gold-head-table">
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title1 ab">Weight (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title2">price (g)</p>
                                    <p class="dsgn-gold-table-title dsgn-gold-table-title3">Value</p>
                                </div>
                                <div class="dsgn-gold-t-field">
                                    <input class="dsgn-gold-number-input dsgn-gold-table-title1" type="number" value="0"
                                        min="0" step="0.1" data-carat="${item.carat}" />
                                    <p class="dsgn-gold-p-i dsgn-gold-table-title2">£34.36</p>
                                    <p class="dsgn-gold-value dsgn-gold-table-title3">£0.00</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dsgn-gold-total-price-body">
                    <h4 class="dsgn-gold-estimate">Estimated Total Payment</h4>
                    <div class="dsgn-gold-metal-totals">
                        <div class="dsgn-gold-metal" data-metal="gold">
                            <p class="dsgn-gold-font16">Gold</p>
                            <p class="dsgn-gold-total-price dsgn-gold-font16">£0.00</p>
                        </div>

                        <div class="dsgn-gold-metal" data-metal="silver">
                            <p class="dsgn-gold-font16">Silver</p>
                            <p class="dsgn-gold-total-price dsgn-gold-font16">£0.00</p>
                        </div>

                        <div class="dsgn-gold-metal" data-metal="platinum">
                            <p class="dsgn-gold-font16">Platinum</p>
                            <p class="dsgn-gold-total-price dsgn-gold-font16">£0.00</p>
                        </div>

                        <div class="dsgn-gold-metal" data-metal="palladium">
                            <p class="dsgn-gold-font16">Palladium</p>
                            <p class="dsgn-gold-total-price dsgn-gold-font16">£0.00</p>
                        </div>

                        <hr class="dsgn-gold-hr" />

                        <div class="dsgn-gold-estimate-price">
                            <p class="dsgn-gold-font16">Estimated</p>
                            <p class="dsgn-gold-estimated-price dsgn-gold-price">£0.00</p>
                        </div>
                    </div>

                    <button class="dsgn-gold-apply">Apply Now</button>
                </div>

            </div>
        </div>
    </div>
</section>

